from dash import dcc

def CryptoGraph():
    return dcc.Graph(id='crypto-graph')
