# config.py

crypto_urls = {
    'Bitcoin': 'https://www.binance.com/pt-BR/price/bitcoin',
    'Ethereum': 'https://www.binance.com/pt-BR/price/ethereum',   
    'Monero': 'https://www.binance.com/pt-BR/price/monero',
    'Solana': 'https://www.binance.com/pt-BR/price/solana',
    'Dogecoin': 'https://www.binance.com/pt-BR/price/dogecoin',
    'Renzo': 'https://cryptologos.cc/logos/ren-ren-logo.svg?v=032',
}
# Adicione URLs para outras criptomoedas aqui